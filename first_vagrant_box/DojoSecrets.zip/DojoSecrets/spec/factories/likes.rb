FactoryGirl.define do
  factory :like do
    secret nil
    user nil
  end
end
