FactoryGirl.define do
  factory :secret do
    content "MyString"
    user nil
  end
end
