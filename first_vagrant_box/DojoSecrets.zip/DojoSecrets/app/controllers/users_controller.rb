class UsersController < ApplicationController
  def index
    redirect_to '/sessions'
  end

  def new
  end

  def register
    @user = User.create user_params
    if @user
      puts 'User created successfullys'
      session[:user_id] = @user.id
      redirect_to "/users/#{@user.id}"
    else
      flash[:error] = @user.errors.full_messages
      redirect_to "users/register"
    end
  end

  def edit
  end

  private
  def user_params
    params.require(:user).permit(:email, :name, :password, :password_confirmation)
  end


end
