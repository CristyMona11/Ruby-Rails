class SessionsController < ApplicationController
  def login
    if session[:user_id]
      redirect_to "/users/#{session[:user_id]}"
    else
      render 'login'
    end
  end

  def create
      # Log User In
      # if authenticate true
          # save user id to session
          # redirect to users profile page
      # if authenticate false
          # add an error message -> flash[:errors] = ["Invalid"]
          # redirect to login page
  end

  def delete
      # Log User out
      # set session[:user_id] to null
      # redirect to login page
  end

end
