class SecretsController < ApplicationController
  def index
    @secrets = current_user.secrets
  end

  def create
  end

  def delete
  end
end
