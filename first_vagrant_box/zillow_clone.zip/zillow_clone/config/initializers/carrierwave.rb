require "carrierwave/orm/activerecord"
