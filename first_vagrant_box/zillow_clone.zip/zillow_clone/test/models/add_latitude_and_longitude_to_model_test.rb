require 'test_helper'

class AddLatitudeAndLongitudeToModelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
