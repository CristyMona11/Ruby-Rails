require 'test_helper'

class PropertiesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
