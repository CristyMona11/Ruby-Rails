class AgentsController < ApplicationController
    def show
    end
end